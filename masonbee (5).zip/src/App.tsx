import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bug, 
  ArrowRight, 
  Check, 
  ChevronRight, 
  Plus, 
  Trash2, 
  MessageSquare, 
  Hammer, 
  Heart, 
  X, 
  Search,
  LayoutDashboard,
  BrainCircuit,
  Wallet,
  Users,
  Info,
  Leaf,
  Send
} from 'lucide-react';
import { Page, Tab, UserProfile, QuizAnswers, BudgetItem, Tradesperson, CommunityPost, Company, Reply } from './types';
import { HoneycombBackground } from './components/HoneycombBackground';
import { Hexagon } from './components/Hexagon';
import { getRenovationPlan, getChatResponse, generateRecommendationImage } from './services/geminiService';

// --- Logo constant — single source of truth ---
const LOGO_URL = "https://img.sanishtech.com/u/a0d7e8eddcc3107a9401a8f0e703cee6.png";

// --- Mock Data ---
const MOCK_TRADESPEOPLE: Tradesperson[] = [
  { id: '1', name: 'James Miller', trade: 'Carpenter', rating: 4.8, experience: 12, availability: 'Next Week', languages: ['English'], area: 'Hackney', isVerified: true },
  { id: '2', name: 'Sarah Ahmed', trade: 'Electrician', rating: 4.9, experience: 8, availability: 'Immediate', languages: ['English', 'Arabic'], area: 'Tower Hamlets', isVerified: true },
  { id: '3', name: 'Piotr Nowak', trade: 'Plumber', rating: 4.7, experience: 15, availability: 'In 2 Weeks', languages: ['English', 'Polish'], area: 'Islington', isVerified: false },
  { id: '4', name: 'Amara Diop', trade: 'Painter & Decorator', rating: 4.9, experience: 6, availability: 'Next Month', languages: ['English', 'French', 'Somali'], area: 'Southwark', isVerified: true },
  { id: '5', name: 'David Smith', trade: 'General Builder', rating: 4.5, experience: 20, availability: 'Immediate', languages: ['English'], area: 'Camden', isVerified: false },
];

const MOCK_POSTS: CommunityPost[] = [
  { 
    id: '1', 
    author: 'Michelle N.', 
    content: 'Anyone have a heavy-duty drill I could borrow for the weekend? Based in Hackney.', 
    type: 'request', 
    likes: 12, 
    replies: [
      { id: 'r1', author: 'Tom S.', content: 'I have one! You can pick it up tomorrow.', timestamp: '1h ago' }
    ], 
    timestamp: '2h ago' 
  },
  { 
    id: '2', 
    author: 'Tom S.', 
    content: 'Found a great salvage yard in East London with loads of Victorian tiles! Check out "The Tile Yard".', 
    type: 'tip', 
    likes: 45, 
    replies: [], 
    timestamp: '5h ago' 
  },
  { 
    id: '3', 
    author: 'Elena G.', 
    content: 'Highly recommend Sarah Ahmed (Electrician) for any rewiring work. Super professional.', 
    type: 'recommendation', 
    likes: 28, 
    replies: [], 
    timestamp: '1d ago' 
  },
];

const MOCK_COMPANIES: Company[] = [
  { id: 'c1', name: 'EcoBuild Solutions', rating: 4.9, availability: 'Mon-Fri', area: 'Greater London', sells: 'Sustainable insulation, recycled timber', isVerified: true },
  { id: 'c2', name: 'Vintage Vault', rating: 4.7, availability: 'Daily', area: 'Hackney', sells: 'Reclaimed furniture, antique fixtures', isVerified: true },
  { id: 'c3', name: 'Green Glass Co.', rating: 4.8, availability: 'By Appt', area: 'Islington', sells: 'Recycled glass countertops, energy-efficient windows', isVerified: true },
];

// --- Main App Component ---
export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>(Page.LANDING);
  const [currentTab, setCurrentTab] = useState<Tab>(Tab.AI_RECOMMENDATIONS);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<QuizAnswers | null>(null);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [aiPlan, setAiPlan] = useState<any>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'bee', text: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // No logo state needed — LOGO_URL constant is used everywhere directly

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput;
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setChatInput('');
    setIsChatLoading(true);
    const response = await getChatResponse(userMsg, { userProfile, quizAnswers });
    setChatMessages(prev => [...prev, { role: 'bee', text: response || "I'm sorry, I'm having trouble connecting to the hive." }]);
    setIsChatLoading(false);
  };

  // --- Landing Page ---
  const LandingPage = () => (
    <div className="relative min-h-screen bg-black flex flex-col items-center justify-center p-6 overflow-hidden">
      <HoneycombBackground color="#F6C114" opacity={0.2} />
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="z-10 flex flex-col items-center text-center"
      >
        <Hexagon size={180} animate={true} fill="#F6C114" stroke="#000000" strokeWidth={6}>
          <img src={LOGO_URL} alt="MasonBee Logo" className="w-20 h-20 object-contain" />
        </Hexagon>
        <h1 className="mt-8 text-6xl font-bold text-[#F6C114] tracking-tighter uppercase italic">MasonBee</h1>
        <p className="mt-4 text-xl text-amber-200/80 font-medium max-w-md">
          Renovate Smart. Spend Less. Live Sustainably.
        </p>
        <button 
          onClick={() => setCurrentPage(Page.SIGN_IN)}
          className="mt-12 px-10 py-4 bg-amber-500 text-black font-bold text-lg rounded-full shadow-[0_0_20px_rgba(245,158,11,0.4)] hover:shadow-[0_0_30px_rgba(245,158,11,0.6)] transition-all flex items-center gap-2 group"
        >
          GET STARTED
          <ArrowRight className="group-hover:translate-x-1 transition-transform" />
        </button>
      </motion.div>
    </div>
  );

  // --- Sign In Page ---
  const SignInPage = () => {
    const [formData, setFormData] = useState({ name: '', email: '', postcode: '' });
    
    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (formData.name && formData.email && formData.postcode) {
        setUserProfile(formData);
        setCurrentPage(Page.QUIZ);
      }
    };

    return (
      <div className="relative min-h-screen bg-amber-400 flex flex-col items-center justify-center p-6 overflow-hidden">
        <HoneycombBackground color="#000000" opacity={0.15} />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="z-10 w-full max-w-md bg-white/90 backdrop-blur-md p-8 rounded-3xl shadow-2xl border-4 border-black"
        >
          <div className="flex justify-center mb-6">
            <Hexagon size={80} fill="#000000" stroke="#F6C114" strokeWidth={4}>
              <img src={LOGO_URL} alt="MasonBee Logo" className="w-10 h-10 object-contain" />
            </Hexagon>
          </div>
          <h2 className="text-3xl font-bold text-black text-center mb-8 uppercase tracking-tight">Join the Hive</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-black uppercase tracking-widest mb-2">Your Name</label>
              <input 
                required
                type="text" 
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 bg-white border-2 border-black rounded-xl focus:ring-4 focus:ring-amber-500/20 outline-none transition-all"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-black uppercase tracking-widest mb-2">Email Address</label>
              <input 
                required
                type="email" 
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-white border-2 border-black rounded-xl focus:ring-4 focus:ring-amber-500/20 outline-none transition-all"
                placeholder="hello@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-black uppercase tracking-widest mb-2">Postcode / Borough</label>
              <input 
                required
                type="text" 
                value={formData.postcode}
                onChange={(e) => setFormData({ ...formData, postcode: e.target.value })}
                className="w-full px-4 py-3 bg-white border-2 border-black rounded-xl focus:ring-4 focus:ring-amber-500/20 outline-none transition-all"
                placeholder="e.g. E8 1AB"
              />
            </div>
            <button 
              type="submit"
              className="w-full py-4 bg-black text-amber-500 font-bold text-lg rounded-xl hover:bg-zinc-900 transition-colors uppercase tracking-widest border-b-4 border-amber-600 active:border-b-0 active:translate-y-1"
            >
              Continue
            </button>
          </form>
        </motion.div>
      </div>
    );
  };

  // --- Quiz Page ---
  const QuizPage = () => {
    const [step, setStep] = useState(0);
    const [answers, setAnswers] = useState<Partial<QuizAnswers>>({
      language: 'English',
      sustainableOnly: true,
    });

    const questions = [
      { id: 'householdType', text: "Is this for a family home or a single/couple?", options: ['Family Home', 'Single/Couple'] },
      { id: 'bedrooms', text: "How many bedrooms are in the property?", options: ['1', '2', '3', '4+'] },
      { id: 'roomRenovating', text: "Which room are you renovating first?", options: ['Kitchen', 'Living Room', 'Bedroom', 'Bathroom', 'Garden'] },
      { id: 'budget', text: "What is your total renovation budget?", options: ['Under £1k', '£1k - £5k', '£5k - £10k', '£10k+'] },
      { id: 'stylePreference', text: "What's your style preference?", options: ['Modern', 'Cosy', 'Minimalist', 'Maximalist', 'Vintage'] },
      { id: 'sustainableOnly', text: "Sustainable and second-hand only, or open to all options?", options: ['Sustainable Only', 'Open to All'] },
      { id: 'language', text: "What language do you prefer?", options: ['English', 'Arabic', 'Urdu', 'Polish', 'Somali', 'Bengali', 'Spanish', 'French'] },
    ];

    // Fixed budget parsing — maps option labels to proper numeric values
    const BUDGET_MAP: Record<string, number> = {
      'Under £1k': 1000,
      '£1k - £5k': 5000,
      '£5k - £10k': 10000,
      '£10k+': 20000,
    };

    const handleAnswer = (value: any) => {
      const currentQ = questions[step];
      let processedValue = value;
      if (currentQ.id === 'bedrooms') processedValue = parseInt(value) || 4;
      if (currentQ.id === 'budget') processedValue = BUDGET_MAP[value] ?? 5000;
      if (currentQ.id === 'sustainableOnly') processedValue = value === 'Sustainable Only';

      const newAnswers = { ...answers, [currentQ.id]: processedValue };
      setAnswers(newAnswers);

      if (step < questions.length - 1) {
        setStep(step + 1);
      } else {
        setQuizAnswers(newAnswers as QuizAnswers);
        setCurrentPage(Page.DASHBOARD);
        setShowTutorial(true);
      }
    };

    return (
      <div className="relative min-h-screen bg-amber-600 flex flex-col items-center justify-center p-6 overflow-hidden">
        <HoneycombBackground color="#000000" opacity={0.2} />
        <motion.div 
          key={step}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          className="z-10 w-full max-w-2xl"
        >
          <div className="flex items-center gap-4 mb-8">
            <Hexagon size={60} fill="#000000" stroke="#F6C114" strokeWidth={3}>
              <img src={LOGO_URL} alt="MasonBee Logo" className="w-8 h-8 object-contain" />
            </Hexagon>
            <div className="bg-white/90 p-4 rounded-2xl rounded-tl-none border-2 border-black shadow-lg">
              <p className="text-lg font-bold text-black">{questions[step].text}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {questions[step].options.map((option) => (
              <button
                key={option}
                onClick={() => handleAnswer(option)}
                className="p-6 bg-black text-amber-500 font-bold text-xl rounded-2xl border-b-4 border-amber-700 hover:bg-zinc-900 transition-all active:border-b-0 active:translate-y-1 text-left flex justify-between items-center group"
              >
                {option}
                <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            ))}
          </div>
          <div className="mt-12 flex justify-center gap-2">
            {questions.map((_, i) => (
              <div key={i} className={`h-2 w-8 rounded-full border border-black ${i <= step ? 'bg-black' : 'bg-black/20'}`} />
            ))}
          </div>
        </motion.div>
      </div>
    );
  };

  // --- Dashboard Components ---

  const Sidebar = () => (
    <div className="hidden md:flex flex-col w-64 bg-black border-r-4 border-[#F6C114] p-6 h-screen sticky top-0">
      <div className="flex items-center gap-3 mb-12">
        <Hexagon size={50} fill="#F6C114" stroke="#000" strokeWidth={3}>
          <img src={LOGO_URL} alt="MasonBee Logo" className="w-6 h-6 object-contain" />
        </Hexagon>
        <h1 className="text-2xl font-bold text-[#F6C114] italic uppercase">MasonBee</h1>
      </div>
      <nav className="flex-1 space-y-4">
        {[
          { id: Tab.AI_RECOMMENDATIONS, icon: BrainCircuit, label: 'AI Plan' },
          { id: Tab.BUDGET_TRACKER, icon: Wallet, label: 'Budget' },
          { id: Tab.FIND_TRADESPERSON, icon: Hammer, label: 'Trades' },
          { id: Tab.COMMUNITY_BOARD, icon: Users, label: 'Community' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentTab(item.id as Tab)}
            className={`w-full flex items-center gap-4 p-4 rounded-xl font-bold transition-all ${
              currentTab === item.id 
                ? 'bg-amber-500 text-black shadow-[0_0_15px_rgba(245,158,11,0.3)]' 
                : 'text-amber-500/60 hover:text-amber-500 hover:bg-white/5'
            }`}
          >
            <item.icon size={24} />
            {item.label}
          </button>
        ))}
      </nav>
      <div className="mt-auto pt-6 border-t border-amber-500/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center font-bold text-black">
            {userProfile?.name[0]}
          </div>
          <div>
            <p className="text-sm font-bold text-amber-500">{userProfile?.name}</p>
            <p className="text-xs text-amber-500/60">{userProfile?.postcode}</p>
          </div>
        </div>
      </div>
    </div>
  );

  const MobileNav = () => (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-black border-t-4 border-amber-500 flex justify-around p-4 z-40">
      {[
        { id: Tab.AI_RECOMMENDATIONS, icon: BrainCircuit },
        { id: Tab.BUDGET_TRACKER, icon: Wallet },
        { id: Tab.FIND_TRADESPERSON, icon: Hammer },
        { id: Tab.COMMUNITY_BOARD, icon: Users },
      ].map((item) => (
        <button
          key={item.id}
          onClick={() => setCurrentTab(item.id as Tab)}
          className={`p-3 rounded-xl transition-all ${
            currentTab === item.id ? 'bg-amber-500 text-black' : 'text-amber-500/60'
          }`}
        >
          <item.icon size={24} />
        </button>
      ))}
    </div>
  );

  const AiRecommendations = () => {
    const [images, setImages] = useState<Record<number, string>>({});
    const [failedImages, setFailedImages] = useState<Record<number, boolean>>({});

    useEffect(() => {
      if (!aiPlan && quizAnswers) {
        setIsLoadingAi(true);
        getRenovationPlan(quizAnswers).then(async (plan) => {
          setAiPlan(plan);
          setIsLoadingAi(false);
          
          if (plan && plan.recommendations) {
            plan.recommendations.forEach(async (rec: any, i: number) => {
              try {
                const img = await generateRecommendationImage(rec.itemName, rec.material, quizAnswers.stylePreference, rec.description);
                if (img) {
                  setImages(prev => ({ ...prev, [i]: img }));
                } else {
                  const fallbackUrl = `https://picsum.photos/seed/${rec.itemName.replace(/\s+/g, '-')}/800/800`;
                  setImages(prev => ({ ...prev, [i]: fallbackUrl }));
                  setFailedImages(prev => ({ ...prev, [i]: true }));
                }
              } catch (err) {
                const fallbackUrl = `https://picsum.photos/seed/${rec.itemName.replace(/\s+/g, '-')}/800/800`;
                setImages(prev => ({ ...prev, [i]: fallbackUrl }));
                setFailedImages(prev => ({ ...prev, [i]: true }));
              }
            });
          }
        });
      }
    }, [quizAnswers]);

    if (isLoadingAi) return (
      <div className="flex flex-col items-center justify-center h-full py-20">
        <Hexagon size={120} animate={true} fill="#F59E0B" stroke="#000" strokeWidth={4}>
          <img src={LOGO_URL} alt="MasonBee Logo" className="w-16 h-16 object-contain" />
        </Hexagon>
        <p className="mt-8 text-2xl font-bold text-amber-500 animate-pulse uppercase tracking-widest">Generating Your Sustainable Plan...</p>
      </div>
    );

    if (!aiPlan) return null;

    const getBadge = (score: number) => {
      if (score >= 90) return { label: 'Queen Bee', color: 'bg-amber-500 text-black' };
      if (score >= 75) return { label: 'Gold Bee', color: 'bg-yellow-400 text-black' };
      if (score >= 50) return { label: 'Silver Bee', color: 'bg-zinc-300 text-black' };
      return { label: 'Bronze Bee', color: 'bg-amber-700 text-white' };
    };

    const badge = getBadge(aiPlan.ecoImpactScore);

    return (
      <div className="space-y-8 pb-24 md:pb-0">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-black border-4 border-amber-500 p-8 rounded-3xl relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-3xl font-bold text-amber-500 mb-4 uppercase tracking-tight">Your Renovation Plan</h2>
                <p className="text-amber-200/80 leading-relaxed text-lg">"{aiPlan.overallAdvice}"</p>
              </div>
              <div className="absolute top-0 right-0 opacity-10 pointer-events-none">
                <img src={LOGO_URL} alt="MasonBee Logo" className="w-40 h-40 object-contain opacity-20" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {aiPlan.recommendations.map((rec: any, i: number) => (
                <div key={i} className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0_0_rgba(0,0,0,1)] hover:translate-x-1 hover:-translate-y-1 transition-all">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h4 className="text-xl font-black text-black uppercase leading-tight">{rec.itemName}</h4>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mt-1">Material: {rec.material}</p>
                    </div>
                    <span className="bg-emerald-100 text-emerald-600 text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 uppercase tracking-widest">
                      <Leaf size={12} /> SUSTAINABLE
                    </span>
                  </div>
                  
                  <div className="mb-4 aspect-square bg-zinc-100 rounded-2xl overflow-hidden border-2 border-black/5 relative group">
                    {images[i] ? (
                      <>
                        <img 
                          src={images[i]} 
                          alt={rec.itemName} 
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        {failedImages[i] && (
                          <div className="absolute bottom-2 right-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded text-[8px] text-white font-bold uppercase tracking-widest">
                            Sample Image
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                        <div className="w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">Generating AI Image...</p>
                      </div>
                    )}
                  </div>

                  <p className="text-zinc-600 text-sm mb-4">{rec.description}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-bold text-zinc-500 uppercase tracking-widest text-[10px]">Source</span>
                      <span className="font-bold text-black">{rec.source}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="font-bold text-zinc-500 uppercase tracking-widest text-[10px]">Est. Cost</span>
                      <span className="font-bold text-[#F6C114]">£{rec.cost}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="font-bold text-zinc-500 uppercase tracking-widest text-[10px]">Saving vs New</span>
                      <span className="font-bold text-emerald-600">£{rec.costNew - rec.cost}</span>
                    </div>
                  </div>
                  <div className="mt-6 pt-4 border-t-2 border-zinc-100 grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-xs font-bold text-zinc-400 uppercase">CO2 Saved</p>
                      <p className="text-lg font-black text-black">{rec.co2Saved}kg</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs font-bold text-zinc-400 uppercase">Waste Avoided</p>
                      <p className="text-lg font-black text-black">{rec.landfillAvoided}kg</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      setBudgetItems([...budgetItems, { 
                        id: Date.now().toString(), 
                        name: rec.itemName, 
                        cost: rec.cost, 
                        isSustainable: true,
                        material: rec.material,
                        placement: rec.placement,
                        assemblyInstructions: rec.assemblyInstructions,
                        refurbishTutorial: rec.refurbishTutorial,
                        imageSeed: rec.imageSeed
                      }]);
                      setCurrentTab(Tab.BUDGET_TRACKER);
                    }}
                    className="w-full mt-6 py-3 bg-black text-[#F6C114] font-bold rounded-xl hover:bg-zinc-900 transition-all uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <Plus size={18} />
                    Add to Hive
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-black border-4 border-[#F6C114] p-8 rounded-3xl flex flex-col items-center text-center">
              <h3 className="text-xl font-bold text-[#F6C114] uppercase tracking-widest mb-8">Eco Impact Score</h3>
              <div className="relative w-48 h-48 mb-6">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <polygon
                    points="50,0 100,25 100,75 50,100 0,75 0,25"
                    fill="none"
                    stroke="#F6C114"
                    strokeWidth="2"
                  />
                  <clipPath id="honeycomb-fill">
                    <rect x="0" y={100 - aiPlan.ecoImpactScore} width="100" height={aiPlan.ecoImpactScore} />
                  </clipPath>
                  <polygon
                    points="50,0 100,25 100,75 50,100 0,75 0,25"
                    fill="#10B981"
                    clipPath="url(#honeycomb-fill)"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-black text-white">{aiPlan.ecoImpactScore}%</span>
                </div>
              </div>
              <div className={`px-6 py-2 rounded-full font-bold uppercase tracking-widest text-sm ${badge.color}`}>
                {badge.label}
              </div>
              <p className="mt-4 text-amber-200/60 text-xs italic">Based on your sustainability choices</p>
            </div>

            <div className="bg-amber-500 border-4 border-black p-6 rounded-3xl">
              <h3 className="text-lg font-bold text-black uppercase mb-4">Total Impact</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center text-amber-500">
                    <Leaf size={24} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-black/60 uppercase">Total CO2 Saved</p>
                    <p className="text-xl font-black text-black">
                      {aiPlan.recommendations.reduce((acc: number, r: any) => acc + r.co2Saved, 0)}kg
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center text-amber-500">
                    <Trash2 size={24} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-black/60 uppercase">Landfill Avoided</p>
                    <p className="text-xl font-black text-black">
                      {aiPlan.recommendations.reduce((acc: number, r: any) => acc + r.landfillAvoided, 0)}kg
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const BudgetTracker = () => {
    const [newItem, setNewItem] = useState({ name: '', cost: '', isSustainable: true });
    const totalBudget = quizAnswers?.budget || 1000;
    const spent = budgetItems.reduce((acc, item) => acc + item.cost, 0);
    const remaining = Math.max(0, totalBudget - spent);
    const overBy = Math.max(0, spent - totalBudget);
    const progress = Math.min(100, (spent / totalBudget) * 100);

    const addItem = () => {
      if (newItem.name && newItem.cost) {
        setBudgetItems([...budgetItems, { 
          id: Date.now().toString(), 
          name: newItem.name, 
          cost: parseFloat(newItem.cost), 
          isSustainable: newItem.isSustainable 
        }]);
        setNewItem({ name: '', cost: '', isSustainable: true });
      }
    };

    return (
      <div className="space-y-8 pb-24 md:pb-0">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-black border-4 border-[#F6C114] p-8 rounded-3xl">
              <div className="flex justify-between items-end mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-[#F6C114] uppercase tracking-tight">Budget Overview</h2>
                  <p className="text-amber-200/60 font-bold uppercase tracking-widest text-xs mt-1">Total Limit: £{totalBudget}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-[#F6C114]/60 uppercase">Remaining</p>
                  <p className={`text-4xl font-black ${remaining > 0 ? 'text-[#F6C114]' : 'text-red-500'}`}>
                    £{remaining}
                  </p>
                </div>
              </div>
              
              <div className="relative h-12 bg-zinc-900 rounded-2xl border-2 border-[#F6C114]/30 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className={`h-full ${progress > 90 ? 'bg-red-500' : 'bg-[#F6C114]'} transition-all duration-500`}
                />
                <div className="absolute inset-0 flex items-center px-4">
                  <div className="flex gap-1">
                    {[...Array(20)].map((_, i) => (
                      <div key={i} className="w-4 h-6 border border-black/20 rounded-sm" />
                    ))}
                  </div>
                </div>
              </div>

              {overBy > 0 && (
                <div className="mt-6 p-4 bg-red-500/10 border-2 border-red-500 rounded-2xl flex items-center gap-4">
                  <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center text-white">
                    <Info size={20} />
                  </div>
                  <div>
                    <p className="text-red-500 font-bold uppercase tracking-widest text-xs">Over Budget Warning</p>
                    <p className="text-red-500 font-black text-lg">You are over by £{overBy}</p>
                  </div>
                </div>
              )}

              {progress > 80 && progress <= 100 && (
                <div className="mt-6 p-4 bg-[#F6C114]/10 border-2 border-[#F6C114] rounded-2xl flex items-center gap-4">
                  <div className="w-10 h-10 bg-[#F6C114] rounded-full flex items-center justify-center text-black">
                    <img src={LOGO_URL} alt="MasonBee Logo" className="w-6 h-6 object-contain" />
                  </div>
                  <p className="text-[#F6C114] font-bold italic">"You're approaching your limit. Consider second-hand alternatives for your next few items to stay on track."</p>
                </div>
              )}
            </div>

            <div className="bg-white border-4 border-black p-8 rounded-3xl shadow-[12px_12px_0_0_rgba(0,0,0,1)]">
              <h3 className="text-xl font-bold text-black uppercase mb-6">Purchase History</h3>
              <div className="space-y-6">
                {budgetItems.length === 0 ? (
                  <p className="text-zinc-400 italic text-center py-8">No items added yet. Start tracking your renovation spend.</p>
                ) : (
                  budgetItems.map(item => (
                    <div key={item.id} className="p-6 bg-zinc-50 rounded-3xl border-2 border-black/5 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${item.isSustainable ? 'bg-emerald-100 text-emerald-600' : 'bg-zinc-200 text-zinc-500'}`}>
                            {item.isSustainable ? <Leaf size={24} /> : <Wallet size={24} />}
                          </div>
                          <div>
                            <p className="font-black text-black uppercase tracking-tight text-lg">{item.name}</p>
                            {item.isSustainable && <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Smart Choice 🌱</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <p className="font-black text-black text-xl">£{item.cost}</p>
                          <button 
                            onClick={() => setBudgetItems(budgetItems.filter(i => i.id !== item.id))}
                            className="text-zinc-300 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </div>

                      {item.placement && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-black/5">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-amber-600">
                              <BrainCircuit size={16} />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Smart Layout Advice</span>
                            </div>
                            <p className="text-sm text-zinc-600 italic">"{item.placement}"</p>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-emerald-600">
                              <Hammer size={16} />
                              <span className="text-[10px] font-bold uppercase tracking-widest">Refurbish Tutorial ({item.material})</span>
                            </div>
                            <p className="text-sm text-zinc-600">{item.refurbishTutorial}</p>
                          </div>
                        </div>
                      )}
                      
                      {item.assemblyInstructions && (
                        <div className="p-4 bg-black/5 rounded-2xl">
                          <div className="flex items-center gap-2 text-black mb-2">
                            <Info size={16} />
                            <span className="text-[10px] font-bold uppercase tracking-widest">Assembly Guide</span>
                          </div>
                          <p className="text-xs text-zinc-500 leading-relaxed">{item.assemblyInstructions}</p>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div className="bg-[#F6C114] border-4 border-black p-8 rounded-3xl h-fit sticky top-8 shadow-[12px_12px_0_0_rgba(0,0,0,1)]">
            <h3 className="text-xl font-bold text-black uppercase mb-6 tracking-tighter">Add Purchase</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-black uppercase tracking-widest mb-1">Item Name</label>
                <input 
                  type="text" 
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                  className="w-full px-4 py-3 bg-white border-2 border-black rounded-xl outline-none focus:ring-4 focus:ring-black/10 transition-all font-bold"
                  placeholder="e.g. Vintage Sofa"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-black uppercase tracking-widest mb-1">Cost (£)</label>
                <input 
                  type="number" 
                  value={newItem.cost}
                  onChange={(e) => setNewItem({ ...newItem, cost: e.target.value })}
                  className="w-full px-4 py-3 bg-white border-2 border-black rounded-xl outline-none focus:ring-4 focus:ring-black/10 transition-all font-bold"
                  placeholder="0.00"
                />
              </div>
              <div className="flex items-center gap-3 py-2">
                <button 
                  onClick={() => setNewItem({ ...newItem, isSustainable: !newItem.isSustainable })}
                  className={`w-6 h-6 rounded border-2 border-black flex items-center justify-center transition-all ${newItem.isSustainable ? 'bg-black text-[#F6C114]' : 'bg-white'}`}
                >
                  {newItem.isSustainable && <Check size={16} strokeWidth={4} />}
                </button>
                <span className="text-sm font-bold text-black uppercase tracking-tight">Sustainable / Second-hand</span>
              </div>
              <button 
                onClick={addItem}
                className="w-full py-4 bg-black text-[#F6C114] font-bold rounded-xl hover:bg-zinc-900 transition-all uppercase tracking-widest flex items-center justify-center gap-2 shadow-[4px_4px_0_0_rgba(0,0,0,0.2)] active:shadow-none active:translate-x-1 active:translate-y-1"
              >
                <Plus size={20} /> Add Item
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const FindTradesperson = () => {
    const [view, setView] = useState<'swipe' | 'grid'>('swipe');
    const [currentIndex, setCurrentIndex] = useState(0);
    const [saved, setSaved] = useState<string[]>([]);
    const [filter, setFilter] = useState({ trade: 'All', language: 'All', rating: 0 });
    const [direction, setDirection] = useState<number>(0);

    const combinedData = useMemo(() => {
      const trades = MOCK_TRADESPEOPLE.map(t => ({ ...t, type: 'individual' as const }));
      const companies = MOCK_COMPANIES.map(c => ({ 
        id: c.id, 
        name: c.name, 
        trade: 'Company', 
        rating: c.rating, 
        experience: 0, 
        availability: c.availability, 
        languages: ['English'], 
        area: c.area, 
        isVerified: c.isVerified,
        sells: c.sells,
        type: 'company' as const 
      }));
      return [...trades, ...companies];
    }, []);

    const filteredData = useMemo(() => {
      return combinedData.filter(t => {
        const matchesTrade = filter.trade === 'All' || t.trade === filter.trade || (filter.trade === 'Company' && t.type === 'company');
        const matchesLanguage = filter.language === 'All' || t.languages.includes(filter.language);
        const matchesRating = t.rating >= filter.rating;
        const matchesSearch = searchQuery === '' || t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.trade.toLowerCase().includes(searchQuery.toLowerCase());
        
        const userAreaPrefix = userProfile?.postcode?.[0]?.toLowerCase();
        const itemAreaPrefix = t.area?.[0]?.toLowerCase();
        const isNearby = !userAreaPrefix || !itemAreaPrefix || userAreaPrefix === itemAreaPrefix || t.area === 'Greater London';

        return matchesTrade && matchesLanguage && matchesRating && matchesSearch && isNearby;
      });
    }, [combinedData, filter, searchQuery, userProfile]);

    // Reset swipe index when filteredData changes (fixes out-of-bounds bug)
    useEffect(() => {
      setCurrentIndex(0);
    }, [filteredData.length]);

    const handleAction = (type: 'skip' | 'save') => {
      setDirection(type === 'skip' ? -1 : 1);
      setTimeout(() => {
        if (type === 'save') {
          const id = filteredData[currentIndex]?.id;
          if (id && !saved.includes(id)) setSaved(prev => [...prev, id]);
        }
        setCurrentIndex(prev => prev + 1);
        setDirection(0);
      }, 300);
    };

    const handleSaveGrid = (id: string) => {
      if (!saved.includes(id)) setSaved(prev => [...prev, id]);
    };

    return (
      <div className="space-y-8 pb-24 md:pb-0">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex bg-black p-1 rounded-xl border-2 border-black">
            <button 
              onClick={() => setView('swipe')}
              className={`px-6 py-2 rounded-lg font-bold uppercase tracking-widest text-xs transition-all ${view === 'swipe' ? 'bg-[#F6C114] text-black' : 'text-zinc-500 hover:text-white'}`}
            >
              Swipe Mode
            </button>
            <button 
              onClick={() => setView('grid')}
              className={`px-6 py-2 rounded-lg font-bold uppercase tracking-widest text-xs transition-all ${view === 'grid' ? 'bg-[#F6C114] text-black' : 'text-zinc-500 hover:text-white'}`}
            >
              Browse All
            </button>
          </div>
          
          <div className="flex flex-wrap gap-4 justify-center">
            <select 
              className="bg-white border-2 border-black rounded-xl px-4 py-2 font-bold uppercase tracking-widest text-[10px] outline-none focus:ring-4 focus:ring-[#F6C114]/20"
              value={filter.trade}
              onChange={(e) => setFilter({ ...filter, trade: e.target.value })}
            >
              <option value="All">All Types</option>
              <option value="Company">Companies</option>
              {['Carpenter', 'Electrician', 'Plumber', 'Painter & Decorator', 'General Builder'].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>

            <select 
              className="bg-white border-2 border-black rounded-xl px-4 py-2 font-bold uppercase tracking-widest text-[10px] outline-none focus:ring-4 focus:ring-[#F6C114]/20"
              value={filter.rating}
              onChange={(e) => setFilter({ ...filter, rating: Number(e.target.value) })}
            >
              <option value={0}>Any Rating</option>
              <option value={4}>4+ Stars</option>
              <option value={4.5}>4.5+ Stars</option>
            </select>

            <select 
              className="bg-white border-2 border-black rounded-xl px-4 py-2 font-bold uppercase tracking-widest text-[10px] outline-none focus:ring-4 focus:ring-[#F6C114]/20"
              value={filter.language}
              onChange={(e) => setFilter({ ...filter, language: e.target.value })}
            >
              <option value="All">Any Language</option>
              {['English', 'Spanish', 'Polish', 'French', 'Arabic', 'Somali'].map(l => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>
        </div>

        {view === 'swipe' ? (
          <div className="max-w-md mx-auto relative h-[550px]">
            <AnimatePresence mode="wait">
              {currentIndex < filteredData.length ? (
                <motion.div 
                  key={filteredData[currentIndex].id}
                  initial={{ x: 0, opacity: 1, scale: 1 }}
                  animate={{ 
                    x: direction * 500, 
                    opacity: direction === 0 ? 1 : 0,
                    rotate: direction * 20
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 bg-white border-4 border-black rounded-[40px] shadow-[12px_12px_0_0_rgba(0,0,0,1)] overflow-hidden flex flex-col"
                >
                  <div className="h-48 bg-black relative flex items-center justify-center overflow-hidden">
                    <HoneycombBackground color="#F6C114" opacity={0.2} />
                    <Hexagon size={120} fill="#F6C114" stroke="#000" strokeWidth={4}>
                      {filteredData[currentIndex].type === 'company' ? (
                        <Search size={48} className="text-black" />
                      ) : (
                        <Hammer size={48} className="text-black" />
                      )}
                    </Hexagon>
                    {filteredData[currentIndex].isVerified && (
                      <div className="absolute top-6 right-6 bg-emerald-500 text-black p-2 rounded-full border-2 border-black shadow-lg flex items-center gap-1">
                        <Check size={16} strokeWidth={4} />
                        <span className="text-[10px] font-black uppercase tracking-tighter pr-1">Verified</span>
                      </div>
                    )}
                    <div className="absolute bottom-4 left-6 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full border border-white/20">
                      <p className="text-[10px] font-black text-[#F6C114] uppercase tracking-widest">
                        {filteredData[currentIndex].type === 'company' ? 'Verified Company' : 'Individual Pro'}
                      </p>
                    </div>
                  </div>
                  <div className="p-8 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-3xl font-black text-black uppercase leading-tight tracking-tighter">{filteredData[currentIndex].name}</h3>
                        <p className="text-amber-600 font-bold uppercase tracking-widest text-sm">{filteredData[currentIndex].trade}</p>
                      </div>
                      <div className="bg-black text-[#F6C114] px-3 py-1 rounded-lg font-black flex items-center gap-1">
                        <Heart size={14} fill="currentColor" /> {filteredData[currentIndex].rating}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="bg-zinc-50 p-3 rounded-2xl border-2 border-black/5">
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">Area</p>
                        <p className="font-bold text-black text-sm">{filteredData[currentIndex].area}</p>
                      </div>
                      <div className="bg-zinc-50 p-3 rounded-2xl border-2 border-black/5">
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">Availability</p>
                        <p className="font-bold text-black text-sm">{filteredData[currentIndex].availability}</p>
                      </div>
                      <div className="bg-zinc-50 p-3 rounded-2xl border-2 border-black/5">
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">Languages</p>
                        <p className="font-bold text-black text-xs truncate">{filteredData[currentIndex].languages.join(', ')}</p>
                      </div>
                      <div className="bg-zinc-50 p-3 rounded-2xl border-2 border-black/5">
                        <p className="text-[10px] font-bold text-zinc-400 uppercase">
                          {filteredData[currentIndex].type === 'company' ? 'Sells' : 'Experience'}
                        </p>
                        <p className="font-bold text-black text-xs truncate">
                          {filteredData[currentIndex].type === 'company' ? filteredData[currentIndex].sells : `${filteredData[currentIndex].experience} Years`}
                        </p>
                      </div>
                    </div>

                    <div className="mt-auto flex gap-4">
                      <button 
                        onClick={() => handleAction('skip')}
                        className="flex-1 py-4 bg-zinc-100 text-zinc-400 font-black rounded-2xl border-2 border-zinc-200 hover:bg-zinc-200 hover:text-zinc-600 transition-all uppercase tracking-widest"
                      >
                        Skip
                      </button>
                      <button 
                        onClick={() => handleAction('save')}
                        className="flex-1 py-4 bg-black text-[#F6C114] font-black rounded-2xl border-2 border-black hover:bg-zinc-900 transition-all uppercase tracking-widest shadow-[4px_4px_0_0_rgba(246,193,20,0.3)]"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="text-center py-20">
                  <Hexagon size={100} fill="#F6C114" stroke="#000" strokeWidth={4}>
                    <img src={LOGO_URL} alt="MasonBee Logo" className="w-12 h-12 object-contain" />
                  </Hexagon>
                  <h3 className="mt-8 text-2xl font-bold text-[#F6C114] uppercase">No more options nearby</h3>
                  <p className="text-zinc-500 font-medium mt-2">Try adjusting your filters or location.</p>
                  <button 
                    onClick={() => setCurrentIndex(0)}
                    className="mt-6 px-8 py-3 bg-black text-[#F6C114] font-bold rounded-xl uppercase tracking-widest"
                  >
                    Refresh Hive
                  </button>
                </div>
              )}
            </AnimatePresence>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredData.map(item => (
              <div key={item.id} className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0_0_rgba(0,0,0,1)] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center text-[#F6C114] relative">
                    {item.type === 'company' ? <Search size={24} /> : <Hammer size={24} />}
                    {item.isVerified && (
                      <div className="absolute -top-2 -right-2 bg-emerald-500 text-black p-1 rounded-full border-2 border-black">
                        <Check size={10} strokeWidth={4} />
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-black font-black">
                    <Heart size={14} fill="currentColor" /> {item.rating}
                  </div>
                </div>
                <h4 className="text-xl font-black text-black uppercase leading-tight tracking-tighter">{item.name}</h4>
                <p className="text-amber-600 font-bold uppercase tracking-widest text-[10px] mb-4">{item.trade}</p>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-zinc-400 font-bold uppercase">Area</span>
                    <span className="text-black font-bold">{item.area}</span>
                  </div>
                  <div className="flex justify-between text-[10px]">
                    <span className="text-zinc-400 font-bold uppercase">Availability</span>
                    <span className="text-black font-bold">{item.availability}</span>
                  </div>
                  {item.type === 'company' ? (
                    <div className="flex flex-col gap-1">
                      <span className="text-zinc-400 font-bold uppercase text-[10px]">Sells</span>
                      <span className="text-black font-bold text-[10px] line-clamp-1">{item.sells}</span>
                    </div>
                  ) : (
                    <div className="flex justify-between text-[10px]">
                      <span className="text-zinc-400 font-bold uppercase">Experience</span>
                      <span className="text-black font-bold">{item.experience} Years</span>
                    </div>
                  )}
                </div>
                <button 
                  onClick={() => handleSaveGrid(item.id)}
                  className={`w-full py-3 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all border-2 ${saved.includes(item.id) ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-black text-[#F6C114] border-black hover:bg-zinc-900'}`}
                >
                  {saved.includes(item.id) ? 'Saved to Hive' : 'Save to Hive'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const CommunityBoard = () => {
    const [posts, setPosts] = useState(MOCK_POSTS);
    const [newPost, setNewPost] = useState('');
    const [postType, setPostType] = useState<'tip' | 'request' | 'recommendation'>('tip');
    const [replyingTo, setReplyingTo] = useState<string | null>(null);
    const [replyText, setReplyText] = useState('');

    const addPost = () => {
      if (newPost) {
        setPosts([{
          id: Date.now().toString(),
          author: userProfile?.name || 'User',
          content: newPost,
          type: postType,
          likes: 0,
          replies: [],
          timestamp: 'Just now'
        }, ...posts]);
        setNewPost('');
      }
    };

    const handleLike = (postId: string) => {
      setPosts(posts.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p));
    };

    const handleReply = (postId: string) => {
      if (!replyText.trim()) return;
      setPosts(posts.map(p => {
        if (p.id === postId) {
          return {
            ...p,
            replies: [...p.replies, {
              id: Date.now().toString(),
              author: userProfile?.name || 'User',
              content: replyText,
              timestamp: 'Just now'
            }]
          };
        }
        return p;
      }));
      setReplyText('');
      setReplyingTo(null);
    };

    const filteredPosts = posts.filter(p => 
      searchQuery === '' || p.content.toLowerCase().includes(searchQuery.toLowerCase()) || p.author.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
      <div className="space-y-8 pb-24 md:pb-0">
        <div className="bg-black border-4 border-[#F6C114] p-8 rounded-3xl shadow-[12px_12px_0_0_rgba(0,0,0,1)]">
          <h2 className="text-2xl font-black text-[#F6C114] uppercase mb-6 tracking-tighter">Hive Community</h2>
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              {(['tip', 'request', 'recommendation'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => setPostType(type)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${
                    postType === type ? 'bg-[#F6C114] text-black border-black' : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
            <textarea 
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              className="w-full bg-zinc-900 text-white border-2 border-zinc-800 p-4 rounded-2xl outline-none focus:border-[#F6C114] transition-all resize-none h-24 font-medium"
              placeholder={
                postType === 'tip' ? "Share a sustainability tip..." :
                postType === 'request' ? "What do you need to borrow?" :
                "Recommend a local find..."
              }
            />
            <div className="flex justify-end">
              <button 
                onClick={addPost}
                className="px-8 py-3 bg-[#F6C114] text-black font-black rounded-xl hover:bg-amber-400 transition-all uppercase tracking-widest shadow-[4px_4px_0_0_rgba(0,0,0,0.2)]"
              >
                Post to Board
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {filteredPosts.map(post => (
            <div key={post.id} className="bg-white border-4 border-black p-6 rounded-3xl shadow-[8px_8px_0_0_rgba(0,0,0,1)] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-black rounded-full border-2 border-[#F6C114] flex items-center justify-center font-black text-[#F6C114]">
                    {post.author[0]}
                  </div>
                  <div>
                    <p className="font-black text-black uppercase tracking-tight">{post.author}</p>
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{post.timestamp}</p>
                  </div>
                </div>
                <span className={`px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border-2 ${
                  post.type === 'tip' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 
                  post.type === 'request' ? 'bg-amber-50 text-amber-600 border-amber-200' : 
                  'bg-blue-50 text-blue-600 border-blue-200'
                }`}>
                  {post.type}
                </span>
              </div>
              <p className="text-zinc-800 font-medium leading-relaxed mb-6 text-lg">{post.content}</p>
              
              <div className="flex gap-6 pt-4 border-t-2 border-zinc-50">
                <button 
                  onClick={() => handleLike(post.id)}
                  className="flex items-center gap-2 text-zinc-400 hover:text-red-500 transition-colors font-black text-xs uppercase tracking-widest group"
                >
                  <Heart size={18} className="group-hover:fill-current" /> {post.likes}
                </button>
                <button 
                  onClick={() => setReplyingTo(replyingTo === post.id ? null : post.id)}
                  className="flex items-center gap-2 text-zinc-400 hover:text-[#F6C114] transition-colors font-black text-xs uppercase tracking-widest"
                >
                  <MessageSquare size={18} /> {post.replies.length}
                </button>
              </div>

              {post.replies.length > 0 && (
                <div className="mt-6 space-y-4 pl-6 border-l-4 border-zinc-100">
                  {post.replies.map(reply => (
                    <div key={reply.id} className="bg-zinc-50 p-4 rounded-2xl border-2 border-black/5">
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-black text-black text-xs uppercase">{reply.author}</span>
                        <span className="text-[10px] font-bold text-zinc-400 uppercase">{reply.timestamp}</span>
                      </div>
                      <p className="text-sm text-zinc-600 font-medium">{reply.content}</p>
                    </div>
                  ))}
                </div>
              )}

              {replyingTo === post.id && (
                <div className="mt-6 flex gap-2">
                  <input 
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    className="flex-1 bg-zinc-50 border-2 border-black rounded-xl px-4 py-2 outline-none focus:ring-4 focus:ring-[#F6C114]/20 font-medium"
                    placeholder="Write a reply..."
                    onKeyDown={(e) => e.key === 'Enter' && handleReply(post.id)}
                  />
                  <button 
                    onClick={() => handleReply(post.id)}
                    className="p-2 bg-black text-[#F6C114] rounded-xl hover:bg-zinc-900 transition-all"
                  >
                    <Send size={20} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // --- Tutorial Overlay ---
  const TutorialOverlay = () => {
    const steps = [
      { 
        target: 'ai-plan', 
        text: "This is your AI-powered renovation plan. We prioritize sustainable and second-hand options to save you money and the planet.",
        tab: Tab.AI_RECOMMENDATIONS
      },
      { 
        target: 'budget', 
        text: "Track every penny here. Our honeycomb progress bar will keep you on target, and we'll nudge you if you're overspending.",
        tab: Tab.BUDGET_TRACKER
      },
      { 
        target: 'trades', 
        text: "Find trusted local tradespeople. Swipe right to save them to your hive, or skip to see more options.",
        tab: Tab.FIND_TRADESPERSON
      },
      { 
        target: 'community', 
        text: "Connect with other homebuyers. Borrow tools, share tips, and build your sustainable home together.",
        tab: Tab.COMMUNITY_BOARD
      }
    ];

    const nextStep = () => {
      if (tutorialStep < steps.length - 1) {
        setTutorialStep(tutorialStep + 1);
        setCurrentTab(steps[tutorialStep + 1].tab);
      } else {
        setShowTutorial(false);
      }
    };

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 w-full max-w-md bg-white border-4 border-black p-8 rounded-[40px] shadow-2xl"
        >
          <div className="flex justify-center mb-6">
            <Hexagon size={80} fill="#F59E0B" stroke="#000" strokeWidth={4}>
              <img src={LOGO_URL} alt="MasonBee Logo" className="w-10 h-10 object-contain" />
            </Hexagon>
          </div>
          <div className="relative bg-amber-100 p-6 rounded-3xl border-2 border-black mb-8">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-amber-100 border-t-2 border-l-2 border-black rotate-45" />
            <p className="text-lg font-bold text-black text-center italic">
              {steps[tutorialStep].text}
            </p>
          </div>
          <div className="flex justify-between items-center">
            <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Step {tutorialStep + 1} of {steps.length}</p>
            <button 
              onClick={nextStep}
              className="px-8 py-3 bg-black text-amber-500 font-bold rounded-xl hover:bg-zinc-900 transition-all uppercase tracking-widest flex items-center gap-2"
            >
              {tutorialStep === steps.length - 1 ? 'Finished' : 'Next Step'}
              <ChevronRight size={18} />
            </button>
          </div>
        </motion.div>
      </div>
    );
  };

  // --- Main Render Logic ---
  if (currentPage === Page.LANDING) return <LandingPage />;
  if (currentPage === Page.SIGN_IN) return <SignInPage />;
  if (currentPage === Page.QUIZ) return <QuizPage />;

  return (
    <div className="relative min-h-screen bg-[#F6C114] flex overflow-hidden">
      <HoneycombBackground color="#000000" opacity={0.1} />
      <Sidebar />
      <main className="flex-1 h-screen overflow-y-auto p-6 md:p-12 relative z-10">
        <header className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
          <div className="flex items-center gap-3 md:hidden">
            <Hexagon size={40} fill="#000" stroke="#F6C114" strokeWidth={2}>
              <img src={LOGO_URL} alt="MasonBee Logo" className="w-6 h-6 object-contain" />
            </Hexagon>
            <h1 className="text-xl font-bold text-black uppercase italic">MasonBee</h1>
          </div>
          
          <div className="relative w-full max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={20} />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  const query = searchQuery.toLowerCase();
                  if (query.includes('budget') || query.includes('wallet')) setCurrentTab(Tab.BUDGET_TRACKER);
                  else if (query.includes('trade') || query.includes('builder') || query.includes('plumber')) setCurrentTab(Tab.FIND_TRADESPERSON);
                  else if (query.includes('community') || query.includes('post')) setCurrentTab(Tab.COMMUNITY_BOARD);
                  else if (query.includes('plan') || query.includes('ai')) setCurrentTab(Tab.AI_RECOMMENDATIONS);
                }
              }}
              className="w-full pl-12 pr-4 py-3 bg-white border-2 border-black rounded-2xl outline-none focus:ring-4 focus:ring-[#F6C114]/20 transition-all"
              placeholder="Search for items, tips or trades..."
            />
          </div>

          <div className="hidden md:flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-bold text-black">{userProfile?.name}</p>
              <p className="text-xs text-zinc-500 font-bold uppercase tracking-widest">{userProfile?.postcode}</p>
            </div>
            <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center font-bold text-[#F6C114] border-2 border-[#F6C114]">
              {userProfile?.name[0]}
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {currentTab === Tab.AI_RECOMMENDATIONS && <AiRecommendations />}
            {currentTab === Tab.BUDGET_TRACKER && <BudgetTracker />}
            {currentTab === Tab.FIND_TRADESPERSON && <FindTradesperson />}
            {currentTab === Tab.COMMUNITY_BOARD && <CommunityBoard />}
          </motion.div>
        </AnimatePresence>
      </main>
      <MobileNav />
      {showTutorial && <TutorialOverlay />}

      {/* AI Chatbot */}
      <div className="fixed bottom-24 md:bottom-8 right-8 z-50">
        <AnimatePresence>
          {isChatOpen && (
            <motion.div 
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              className="absolute bottom-20 right-0 w-80 md:w-96 h-[500px] bg-white border-4 border-black rounded-3xl shadow-2xl flex flex-col overflow-hidden"
            >
              <div className="bg-black p-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <img src={LOGO_URL} alt="MasonBee Logo" className="w-8 h-8 object-contain" />
                  <span className="text-amber-500 font-bold uppercase tracking-widest text-sm">MasonBee AI</span>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="text-amber-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-zinc-50">
                {chatMessages.length === 0 && (
                  <div className="text-center py-10">
                    <img src={LOGO_URL} alt="MasonBee Logo" className="w-16 h-16 object-contain mx-auto mb-4 opacity-20" />
                    <p className="text-zinc-400 font-bold italic">"Hello! I'm MasonBee. How can I help you with your renovation today?"</p>
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-2xl font-medium text-sm ${
                      msg.role === 'user' ? 'bg-amber-500 text-black rounded-tr-none' : 'bg-black text-white rounded-tl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-black text-white p-3 rounded-2xl rounded-tl-none flex gap-1">
                      <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce" />
                      <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
              </div>
              <div className="p-4 border-t-2 border-zinc-100 flex gap-2">
                <input 
                  type="text" 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1 px-4 py-2 bg-zinc-100 border-2 border-black rounded-xl outline-none focus:border-amber-500 transition-all text-sm"
                  placeholder="Ask me anything..."
                />
                <button 
                  onClick={handleSendMessage}
                  className="p-2 bg-black text-amber-500 rounded-xl hover:bg-zinc-900 transition-all"
                >
                  <Send size={20} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <button 
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="w-16 h-16 bg-black border-4 border-amber-500 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all group"
        >
          <img src={LOGO_URL} alt="MasonBee Logo" className="w-10 h-10 object-contain group-hover:rotate-12 transition-all" />
        </button>
      </div>
    </div>
  );
}
