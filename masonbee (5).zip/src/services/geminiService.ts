import { GoogleGenAI, Type } from "@google/genai";
import { QuizAnswers } from "../types";

const apiKey = process.env.GEMINI_API_KEY || "";
const ai = new GoogleGenAI({ apiKey });

export async function getRenovationPlan(answers: QuizAnswers) {
  const prompt = `
    As MasonBee, a mature and empowering renovation expert, provide a personalized renovation plan for a first-time homebuyer in the UK.
    User Profile:
    - Household: ${answers.householdType}
    - Bedrooms: ${answers.bedrooms}
    - Room: ${answers.roomRenovating}
    - Budget: £${answers.budget}
    - Style: ${answers.stylePreference}
    - Sustainability Preference: ${answers.sustainableOnly ? "Strictly second-hand/sustainable" : "Open to all, but prefer sustainable"}
    - Language: ${answers.language}

    Requirements:
    1. Focus on sustainable and second-hand options first (Facebook Marketplace, Gumtree, Freecycle, charity shops, salvage yards).
    2. Provide 3 specific recommendations for the ${answers.roomRenovating}.
    3. For each recommendation, include:
       - Item name
       - Sustainable source
       - Estimated cost (second-hand)
       - Cost comparison vs buying new
       - CO2 saved (kg)
       - Landfill waste avoided (kg)
       - Material (e.g., Solid Oak, Recycled Pine, Velvet)
       - Placement Advice (Where to put it in the room)
       - Image Seed (A 1-2 word descriptive seed for a placeholder image)
       - Assembly Instructions (Brief steps)
       - Refurbish Tutorial (Brief steps based on the material)
    4. Provide an overall "Eco Impact Score" (0-100).
    5. Use a mature, empowering tone.
    6. Return the response in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-05-20", // Fixed: gemini-3-flash-preview does not exist
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ecoImpactScore: { type: Type.NUMBER },
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  itemName: { type: Type.STRING },
                  source: { type: Type.STRING },
                  cost: { type: Type.NUMBER },
                  costNew: { type: Type.NUMBER },
                  co2Saved: { type: Type.NUMBER },
                  landfillAvoided: { type: Type.NUMBER },
                  description: { type: Type.STRING },
                  material: { type: Type.STRING },
                  placement: { type: Type.STRING },
                  imageSeed: { type: Type.STRING },
                  assemblyInstructions: { type: Type.STRING },
                  refurbishTutorial: { type: Type.STRING },
                },
                required: [
                  "itemName", "source", "cost", "costNew", "co2Saved",
                  "landfillAvoided", "description", "material", "placement",
                  "imageSeed", "assemblyInstructions", "refurbishTutorial"
                ],
              },
            },
            overallAdvice: { type: Type.STRING },
          },
          required: ["ecoImpactScore", "recommendations", "overallAdvice"],
        },
      },
    });

    // Fixed: guard against null/empty response text before parsing
    const text = response.text;
    if (!text) {
      console.error("Empty response from Gemini API");
      return null;
    }
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating renovation plan:", error);
    return null;
  }
}

export async function getChatResponse(message: string, context: any) {
  const prompt = `
    You are MasonBee, a mature, empowering, and trustworthy renovation assistant for first-time homebuyers in the UK.
    Your goal is to help users renovate their homes sustainably and within a small budget.
    
    User Profile: ${JSON.stringify(context.userProfile || {})}
    User Preferences (Quiz Answers): ${JSON.stringify(context.quizAnswers || {})}
    
    User Message: ${message}

    Guidelines:
    1. Be professional, encouraging, and practical.
    2. Prioritize sustainable, second-hand, and cost-effective solutions.
    3. Use the user's preferences (e.g., style, room, budget) to tailor your advice.
    4. If the user asks about specific items, suggest where they can find them second-hand (e.g., Facebook Marketplace, charity shops).
    5. Keep responses VERY concise (max 2-3 short sentences). Do not be wordy.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-05-20", // Fixed: gemini-3-flash-preview does not exist
      contents: prompt,
    });
    return response.text ?? "I'm sorry, I received an empty response. Please try again.";
  } catch (error) {
    console.error("Error getting chat response:", error);
    return "I'm sorry, I'm having trouble connecting to the hive right now. Please try again later.";
  }
}

// generateLogo removed — logo is now a static PNG constant in App.tsx

export async function generateRecommendationImage(
  itemName: string,
  material: string,
  style: string,
  description: string
) {
  const prompt = `A realistic, high-quality professional interior design photograph of a ${itemName}. 
  Style: ${style}. 
  Material: ${material}. 
  Details: ${description}. 
  The furniture is placed in a realistic, well-lit room with natural lighting. 4k resolution, professional architectural photography, clean composition.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-05-20",
      contents: {
        parts: [{ text: prompt }],
      },
    });

    // Fixed: null-check candidates before accessing
    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) {
      console.warn("No candidates returned from image generation.");
      return null;
    }

    const parts = candidates[0]?.content?.parts;
    if (!parts) return null;

    for (const part of parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error: any) {
    if (error?.message?.includes("quota") || error?.status === "RESOURCE_EXHAUSTED") {
      console.warn("Gemini API quota exhausted for recommendation image. Using fallback.");
    } else {
      console.error("Error generating recommendation image:", error);
    }
    return null;
  }
}
