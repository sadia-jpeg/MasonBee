import React from 'react';
import { motion } from 'motion/react';

interface HexagonProps {
  children?: React.ReactNode;
  className?: string;
  onClick?: () => void;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  size?: number;
  animate?: boolean;
}

export const Hexagon: React.FC<HexagonProps> = ({
  children,
  className = '',
  onClick,
  fill = '#F59E0B',
  stroke = '#000000',
  strokeWidth = 4,
  size = 100,
  animate = false,
}) => {
  const points = "50,0 100,25 100,75 50,100 0,75 0,25";

  return (
    <motion.div
      className={`relative flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
      onClick={onClick}
      whileHover={onClick ? { scale: 1.05 } : {}}
      whileTap={onClick ? { scale: 0.95 } : {}}
      animate={animate ? { y: [0, -10, 0] } : {}}
      transition={animate ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
    >
      <svg
        viewBox="0 0 100 100"
        className="absolute inset-0 w-full h-full drop-shadow-lg"
        // Fixed: "none" was distorting the hexagon on non-square containers.
        // "xMidYMid meet" preserves aspect ratio and centres the shape correctly.
        preserveAspectRatio="xMidYMid meet"
      >
        <polygon
          points={points}
          fill={fill}
          stroke={stroke}
          strokeWidth={strokeWidth}
          strokeLinejoin="round"
        />
      </svg>
      <div className="relative z-10 flex flex-col items-center justify-center w-full h-full p-4 text-center">
        {children}
      </div>
    </motion.div>
  );
};
