import React, { useId } from 'react';

interface HoneycombBackgroundProps {
  color?: string;
  opacity?: number;
}

export const HoneycombBackground: React.FC<HoneycombBackgroundProps> = ({
  color = '#F59E0B',
  opacity = 0.1,
}) => {
  // Fixed: hardcoded id="honeycomb" caused SVG pattern clashes when multiple
  // instances rendered on the same page (e.g. landing + sign-in during transitions).
  // useId() gives each instance a guaranteed unique ID.
  const id = useId().replace(/:/g, ''); // strip colons — invalid in SVG id values
  const patternId = `honeycomb-${id}`;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern
            id={patternId}
            x="0"
            y="0"
            width="56"
            height="100"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M28 66L0 50L0 16L28 0L56 16L56 50L28 66L28 100"
              fill="none"
              stroke={color}
              strokeWidth="1"
              strokeOpacity={opacity}
            />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#${patternId})`} />
      </svg>
    </div>
  );
};