export enum Page {
  LANDING = 'landing',
  SIGN_IN = 'sign_in',
  QUIZ = 'quiz',
  DASHBOARD = 'dashboard',
}

export enum Tab {
  AI_RECOMMENDATIONS = 'ai_recommendations',
  BUDGET_TRACKER = 'budget_tracker',
  FIND_TRADESPERSON = 'find_tradesperson',
  COMMUNITY_BOARD = 'community_board',
}

export interface UserProfile {
  name: string;
  email: string;
  postcode: string;
}

export interface QuizAnswers {
  householdType: string;
  bedrooms: number;
  roomRenovating: string;
  budget: number;
  stylePreference: string;
  sustainableOnly: boolean;
  language: string;
}

export interface BudgetItem {
  id: string;
  name: string;
  cost: number;
  isSustainable: boolean;
  material?: string;
  placement?: string;
  imageSeed?: string;
  assemblyInstructions?: string;
  refurbishTutorial?: string;
}

export interface Tradesperson {
  id: string;
  name: string;
  trade: string;
  rating: number;
  experience: number;
  availability: string;
  languages: string[];
  area: string;
  isVerified?: boolean;
}

export interface Reply {
  id: string;
  author: string;
  content: string;
  timestamp: string;
}

export interface CommunityPost {
  id: string;
  author: string;
  content: string;
  type: 'tip' | 'request' | 'recommendation';
  likes: number;
  replies: Reply[];
  timestamp: string;
}

export interface Company {
  id: string;
  name: string;
  rating: number;
  availability: string;
  area: string;
  sells: string;
  isVerified?: boolean;
}
